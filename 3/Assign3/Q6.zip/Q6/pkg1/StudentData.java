package Assign3.Q6.pkg1;

public class StudentData {
    private String id;
    private String name;

    public void setId(String id){
        this.id = id;
    }
    public void setName(String name){
        this.name = name;
    }
    public String getId(){
        return id;
    }
    public String getName(){
        return name;
    }
}
